
import streamlit as st
import pydeck as pdk
from shapely.geometry import LineString
from vtol_path_optimizer import optimize_path  # Make sure this module exists

st.set_page_config(page_title="VTOL Flight Path Optimizer", layout="centered")
st.title("VTOL Flight Path Optimizer")

st.markdown("""
This app lets you plan VTOL (Vertical Take-Off and Landing) flight paths.
Enter latitude and longitude for your start and end points, then select a cruise altitude.
""")

# Input Fields
start = st.text_input("Enter start coordinates (lat, lon)", "28.538336, -81.379234")
end = st.text_input("Enter end coordinates (lat, lon)", "28.4258, -81.4221")
altitude = st.slider("Select cruise altitude (meters)", min_value=50, max_value=500, value=150, step=10)

if st.button("Optimize Route"):
    try:
        # Convert inputs to floats
        start_coords = tuple(map(float, start.split(',')))
        end_coords = tuple(map(float, end.split(',')))

        # Call optimization function
        path = optimize_path(start_coords, end_coords, altitude)

        if not path or path.is_empty:
            st.error("No valid path could be generated.")
        else:
            # Flip (lon, lat) -> (lat, lon) for pydeck
            latlon_path = [[lat, lon] for lon, lat in path.coords]
            midpoint = latlon_path[len(latlon_path) // 2]

            layer = pdk.Layer(
                "PathLayer",
                data=[{"path": latlon_path}],
                get_path="path",
                get_width=4,
                get_color=[255, 0, 0],
                width_min_pixels=2,
            )

            st.pydeck_chart(pdk.Deck(
                map_style="mapbox://styles/mapbox/light-v9",
                initial_view_state=pdk.ViewState(
                    latitude=midpoint[0],
                    longitude=midpoint[1],
                    zoom=12,
                    pitch=0,
                ),
                layers=[layer],
            ))
    except Exception as e:
        st.error(f"Error processing input: {e}")
